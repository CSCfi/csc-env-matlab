#!/bin/sh
# This wrapper script is intended to support independent execution.
#
# This script uses the following environment variables set by the submit MATLAB code:
# PARALLEL_SERVER_MATLAB_EXE  - the MATLAB executable to use
# PARALLEL_SERVER_MATLAB_ARGS - the MATLAB args to use

# Copyright 2010-2022 The MathWorks, Inc.

if [ ! $TZ ] ; then
    export TZ=$(timedatectl | grep "Time zone" | cut -d ":" -f2 | cut -d " " -f2)
fi

#MW
:<<'NOT_SUPPORTED_RIGHT_NOW'
LOG_FOLDER=$HOME
if [ ! $LOG_FOLDER ] ; then
    echo "Job history not enabled."
    loggingEnabled=0
else
    loggingEnabled=1
    logfile=$LOG_FOLDER/$SLURM_JOB_ID
fi

if [ $loggingEnabled -eq 1 ] ; then
    if [ ! -d $LOG_FOLDER ] ; then
	mkdir -p $LOG_FOLDER
	STATUS=$?
	if [ $STATUS -ne 0 ] ; then
	    echo "Failed to make job directory: $LOG_FOLDER"
	    loggingEnabled=0
	else
	    chmod 777 $LOG_FOLDER
	fi
    fi
fi

if [ $loggingEnabled -eq 1 ] ; then
    # MW: What about version?
    echo "User      : $USER"                                   >> $logfile
    echo "NumWorkers: 1"                                       >> $logfile
    echo " "                                                   >> $logfile
    scontrol show job -d $SLURM_JOB_ID | grep TimeLimit | sed -e 's/[ \t]*//' | cut -f 2 -d" " >> $logfile
    scontrol show job -d $SLURM_JOB_ID | grep Partition | sed -e 's/[ \t]*//' | cut -f 1 -d" " >> $logfile
    scontrol show job -d $SLURM_JOB_ID | grep NodeList  | sed -e 's/[ \t]*//' | grep ^NodeList >> $logfile
    scontrol show job -d $SLURM_JOB_ID | grep -i tres   | sed -e 's/[ \t]*//'                  >> $logfile
    scontrol show job -d $SLURM_JOB_ID | grep 'Nodes='  | sed -e 's/[ \t]*//'                  >> $logfile
    scontrol show job -d $SLURM_JOB_ID | grep MinCPUs   | sed -e 's/[ \t]*//'                  >> $logfile
    scontrol show job -d $SLURM_JOB_ID | grep Features  | sed -e 's/[ \t]*//' | cut -f 1 -d" " >> $logfile
    #echo " "                                                   >> $logfile
    # MW: Or compress it to a single line (we don't get NumTasks or CPUs/Task)
    #sacct --allocations --format "Timelimit,Partition,NodeList,AllocTRES%50,Constraints" -j $SLURM_JOB_ID >> $logfile
fi
NOT_SUPPORTED_RIGHT_NOW

# If PARALLEL_SERVER_ environment variables are not set, assign any
# available values with form MDCE_ for backwards compatibility
PARALLEL_SERVER_MATLAB_EXE=${PARALLEL_SERVER_MATLAB_EXE:="${MDCE_MATLAB_EXE}"}
PARALLEL_SERVER_MATLAB_ARGS=${PARALLEL_SERVER_MATLAB_ARGS:="${MDCE_MATLAB_ARGS}"}

# Echo the node that the scheduler has allocated to this job:
echo "The scheduler has allocated the following node to this job: `hostname`"

if [ ! -z "${SLURM_ARRAY_TASK_ID}" ] ; then
    # Use job arrays
    TASK_ID=$((${SLURM_ARRAY_TASK_ID}+${PARALLEL_SERVER_TASK_ID_OFFSET}))
    export PARALLEL_SERVER_TASK_LOCATION="${PARALLEL_SERVER_JOB_LOCATION}/Task${TASK_ID}";
    export MDCE_TASK_LOCATION="${MDCE_JOB_LOCATION}/Task${TASK_ID}";
fi

# Construct the command to run.
CMD="\"${PARALLEL_SERVER_MATLAB_EXE}\" ${PARALLEL_SERVER_MATLAB_ARGS}"

# Echo the command so that it is shown in the output log.
echo "Executing: $CMD"

:<<'NOT_SUPPORTED_RIGHT_NOW_2'
start=`date +%s`
NOT_SUPPORTED_RIGHT_NOW_2
# Execute the command.
eval $CMD
:<<'NOT_SUPPORTED_RIGHT_NOW_3'
now=`date +%s`
elapsed=$((now-start))

if [ $loggingEnabled -eq 1 ] ; then
    echo " "                                                   >> $logfile
    echo "Duration: $elapsed seconds "                         >> $logfile
fi
NOT_SUPPORTED_RIGHT_NOW_3

EXIT_CODE=${?}
echo "Exiting with code: ${EXIT_CODE}"
exit ${EXIT_CODE}
