function cscWorkspaces(cluster, project)
% Show quota of project(s)

% Copyright 2022 The MathWorks, Inc.

narginchk(1,2)
if nargin==1
    project = '';
else
    project = ['p ' char(project)];
end

% The plugin scripts are not on the path (needed for
% runSchedulerCommand).  Need to change directories to it first.
% Tried calling feval instead, but
% feval(/very/long/path/to/plugin/scripts/fcn) won't work.
odir = cd(fullfile(cluster.PluginScriptsLocation,"private"));
% Change back to the old directory on cleanup
x = onCleanup(@()cd(odir));

% Set PATH in case tools are not on the path
commandToRun = sprintf('export PATH=/appl/opt/csc-cli-utils/bin:$PATH; csc-workspaces -v%s', project);
[FAILED, result] = runSchedulerCommand(cluster, commandToRun);
result = strtrim(result);
if FAILED~=false
    error("Failed to get workspaces: " + result)
end
disp(result)

end
