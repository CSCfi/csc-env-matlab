classdef cscTools
    %CSCTOOLS Utility wrappers for common commands.

    % Copyright 2026 The MathWorks, Inc.

    methods (Access=private)
        function obj = cscTools
        end
    end

    methods (Static, Hidden=true)
        function print_affinity(cluster)
            arguments
                cluster {mustBeA(cluster,'parallel.cluster.Generic')}
            end

            cscTools.runAndShow(cluster, 'csc-print-affinity', 'Failed to create report');
        end
    end

    methods (Static)
        function projects(cluster,flag)
            arguments
                cluster {mustBeA(cluster,'parallel.cluster.Generic')}
                flag {mustBeTextScalar} = ""
            end

            commandToRun = sprintf('csc-projects %s',char(flag));
            cscTools.runAndShow(cluster, commandToRun, 'Failed to create report');
        end

        function workspaces(cluster,flag)
            arguments
                cluster {mustBeA(cluster,'parallel.cluster.Generic')}
                flag {mustBeTextScalar} = ""
            end

            commandToRun = sprintf('csc-workspaces %s',char(flag));
            cscTools.runAndShow(cluster, commandToRun, 'Failed to create report');
        end

        function seff(job, flag)
            arguments
                job {mustBeA(job,{'parallel.job.CJSIndependentJob','parallel.job.CJSCommunicatingJob'})}
                flag {mustBeTextScalar} = ""
            end

            cluster = job.Parent;

            jobID = job.getTaskSchedulerIDs{1};
            commandToRun = sprintf('seff %s %s', flag, jobID);
            cscTools.runAndShow(cluster, commandToRun, 'Failed to create report');
        end

    end

    methods (Static, Access = private)
        function runAndShow(cluster, commandToRun, emsg)

            % The plugin scripts are not on the path (needed for
            % runSchedulerCommand).  Need to change directories to it first.
            % Tried calling feval instead, but
            % feval(/very/long/path/to/plugin/scripts/fcn) won't work.
            odir = cd(fullfile(cluster.PluginScriptsLocation,"private"));
            % Change back to the old directory on cleanup
            x = onCleanup(@()cd(odir));

            commandToRun = sprintf('PATH=/appl/soft/manual/general/x86_64/csc-tools/bin:$PATH; %s', commandToRun);
            [FAILED, result] = runSchedulerCommand(cluster, commandToRun);

            result = strtrim(result);
            if FAILED
                throwAsCaller(MException('cscTools:CommandFailed',...
                    '%s (status=%d): %s', emsg, FAILED, result));
            end

            fprintf('%s\n', string(result));
        end
    end
end
