function postConstructFcn(cluster)
%POSTCONSTRUCTFCN Perform custom configuration after call to PARCLUSTER
%
% POSTCONSTRUCTFCN(CLUSTER) execute code on cluster object CLUSTER.
%
% See also parcluster.

% Copyright 2023-2026 The MathWorks, Inc.


%%%%%%%%%%%%%%%%%%%%%
% Functions to call %
%%%%%%%%%%%%%%%%%%%%%

% Checks for a complete RJSL, as often the local hostname is missing on macOS and Linux.
iRJSLHostnameCheck(cluster);

% Uncomment the following line if the cluster has a non-standard RJSL that requires user input or
% a cluster 'getRemoteConnection' command rather than relying on the same pattern for all users.
% See function for full instructions.
%iNonstandardRJSL(cluster);

% Uncomment the following line if you'd like to display a banner informing the user that
% an AdditionalProperties value is required to submit a job.  See function for more info.
iRequiredPropertiesBanner(cluster);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Required Properties Banner %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function iRequiredPropertiesBanner(cluster)
% Displays instructions for setting missing required scheduler properties.
% Runs only once per session to avoid spamming the user.

    persistent DONE
    mlock

    if DONE
        % We've already warned to correctly set the AdditionalProperties
        return
    else
        % Only want to check once per MATLAB session
        DONE = true;
    end

    % Define profile name, removing all R20XXx references.
    ap = cluster.AdditionalProperties;
    profile = split(cluster.Profile);
    keep = cellfun(@isempty, regexp(profile, '^R20\d{2}[ab]\>'));
    profile = strjoin(profile(keep));

    % Add one entry for each property required by getCommonSubmitArgs.
    % The AccountName entry automatically prompts the user to save the profile.
    requirements = [ ...
        iRequirement('AccountName', 'char', ...
        '% Set AccountName', ...
        'c.AdditionalProperties.AccountName = ''account-name'';')
        iRequirement('WallTime', 'char', ...
        '% 5 hour, 30 minute walltime', ...
        'c.AdditionalProperties.WallTime = ''05:30:00'';')
    ];

    % Sort properties alphabetically before moving properties that require
    % saving the profile first.
    [~, sortIdx] = sort({requirements.Name});
    requirements = requirements(sortIdx);

    % Identify which required properties have not been set.
    isMissing = false(size(requirements));
    for idx = 1:numel(requirements)
        requirement = requirements(idx);
        value = validatedPropValue(ap, requirement.Name, ...
            requirement.Type);
        isMissing(idx) = isempty(value);
    end

    % Keep only missing properties so set values are not displayed.
    missingRequirements = requirements(isMissing);
    if isempty(missingRequirements)
        return
    end

    % Display properties that require saving the profile before all others.
    requiresProfileSave = [missingRequirements.SaveProfile];
    missingRequirements = missingRequirements( ...
        [find(requiresProfileSave), find(~requiresProfileSave)]);

    % Format the missing property names for the banner's opening sentence.
    propertyList = iFormatPropertyList({missingRequirements.Name});

    % Build the command-window examples for setting those properties.
    exampleText = iBuildPropertyExamples(missingRequirements);

    % Display the completed banner using the profile name and examples.
    fprintf('\n\tMust set %s before submitting jobs to %s.  E.g.\n\n%s\n', ...
        propertyList, profile, exampleText)
end

function requirement = iRequirement(propertyName, propertyType, ...
        exampleTitle, exampleCode)
% Package the validation and display metadata for one required property.

    % Name and Type are passed to validatedPropValue.
    % ExampleTitle and ExampleCode form the property's command-window help.
    % SaveProfile field includes properties that prompt the user to save their profile
    % for use in future sessions.
    requirement = struct( ...
        'Name', propertyName, ...
        'Type', propertyType, ...
        'ExampleTitle', exampleTitle, ...
        'ExampleCode', exampleCode, ...
        'SaveProfile', strcmp(propertyName, 'AccountName'));
end

function propertyList = iFormatPropertyList(propertyNames)
% Format property names as a grammatically correct list for the banner.

    switch numel(propertyNames)
        case 1
            % A single property does not need a separator.
            propertyList = propertyNames{1};
        case 2
            % Join two properties with "and" and no comma.
            propertyList = sprintf('%s and %s', propertyNames{:});
        otherwise
            % Separate three or more properties with commas and place
            % "and" before the final property.
            propertyList = sprintf('%s, and %s', ...
                strjoin(propertyNames(1:end-1), ', '), propertyNames{end});
    end
end

function exampleText = iBuildPropertyExamples(requirements)
% Build the command-window example for all missing required properties.

    % Allocate one segment for parcluster, a conditional segment for saving
    % persistent properties, and one segment for each property.
    requiresProfileSave = [requirements.SaveProfile];
    numSegments = 1 + numel(requirements) + any(requiresProfileSave);
    segments = cell(1, numSegments);

    % Every example begins by retrieving the current cluster profile.
    segments{1} = sprintf('\t>> c = parcluster;\n\n');

    segmentIdx = 2;
    for requirementIdx = 1:numel(requirements)
        requirement = requirements(requirementIdx);

        % Separate property examples with a blank line. The first property
        % already follows the blank line after the parcluster command.
        separator = repmat(newline, 1, requirementIdx > 1);

        % Add the property's explanatory title and example assignment.
        segments{segmentIdx} = sprintf('%s\t>> %s\n\t>> %s\n', ...
            separator, requirement.ExampleTitle, requirement.ExampleCode);
        segmentIdx = segmentIdx + 1;

        % Add one save command after the final property that needs to be
        % persisted.
        if requiresProfileSave(requirementIdx) && ...
                ~any(requiresProfileSave(requirementIdx + 1:end))
            segments{segmentIdx} = sprintf( ...
                '\n\t>> %% Save profile for future use\n\t>> c.saveProfile\n');
            segmentIdx = segmentIdx + 1;
        end
    end

    % Combine the prebuilt segments into one string for fprintf.
    exampleText = [segments{:}];
end


%%%%%%%%%%%%%%%%%%%%%%%%
% RJSL Hostname Check %
%%%%%%%%%%%%%%%%%%%%%%%%

function iRJSLHostnameCheck(cluster)

    % Only perform this function if an RJSL is set.
    if isprop(cluster.AdditionalProperties, 'RemoteJobStorageLocation')

        % First, get the cluster profile name so we can look at it in the string.  We only want to perform these steps if the RJSL is set to a
        % standard version **AND** it's missing the HOST variable.
        profileName = strsplit(cluster.Profile, ' ');
        clusterName = lower(profileName{1});
        defaultRJSLString = strcat('/.matlab/generic_cluster_jobs/', clusterName);

        % Check to see if the RJSL has the default string
        if contains(cluster.AdditionalProperties.RemoteJobStorageLocation, defaultRJSLString)

            % If RJSL has default string, then we next want to get the hostname variable.
            if ispc
                hostVariable = getenv('COMPUTERNAME');
            else
                hostVariable = getenv('HOST');
            end

            % We then need to update the RJSL with a new value if the hostVariable
            % is empty AND the RJSL ends with '/' indicating the hostname was never set.
            if isempty(hostVariable) && endsWith(cluster.AdditionalProperties.RemoteJobStorageLocation, '/')

                % Get hostname from the system command
                [cmdFailed, systemHostname] = system('hostname');

                % If the system command succeeds and returns a hostname, append it to the end of the RJSL.
                if ~cmdFailed && ~isempty(systemHostname)
                    cluster.AdditionalProperties.RemoteJobStorageLocation = strcat(cluster.AdditionalProperties.RemoteJobStorageLocation, systemHostname);
                else
                    % The system command failed or did not return a hostname, so create a placeholder.
                    % First get an appropriate placeholder for the hostname
                    fixedPart = 'remoteClient-';
                    % Generate a temporary name and split it into parts
                    pathParts = strsplit(tempname, filesep);
                    % Extract the first 7 characters of the last section
                    randomPart = pathParts{end}(1:7);
                    % Assemble the new hostname
                    newHostname = [fixedPart, randomPart];

                    % Now that we have a new hostname, we can append it at the end
                    % (since if it's empty, there's just an empty space there after the /)
                    cluster.AdditionalProperties.RemoteJobStorageLocation = strcat(cluster.AdditionalProperties.RemoteJobStorageLocation, newHostname);
                end
                cluster.saveProfile
            end
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Non-Standard RemoteJobStorageLocation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function iNonstandardRJSL(cluster)

    % Only perform this function if an RJSL is set.
    if isprop(cluster.AdditionalProperties, 'RemoteJobStorageLocation')

        % The following code block is used if the cluster has a non-standard RJSL that cannot rely on the same pattern for all users.
        % You MUST also make corresponding changes to the cluster.conf file(s).

        % Step One -- Modify .conf file(s) with "PLACEHOLDER_DIR" where the custom value should go.
        % Exact placement of "PLACEHOLDER_DIR" depends on if MATLAB will use a remote connection to automatically obtain the user's
        % $HOME directory on the cluster (which automatically includes the username value) or if they will be prompted for the
        % root of a custom RJSL (which does not automatically include the username value).

        % Example hpcDesktop.conf file that uses a remote connection to fetch the user's $HOME directory automatically:

        % # Remote Job Storage Location
        % # Directory on the cluster's file system to be used as the remote job storage location.
        % RemoteJobStorageLocation (Windows) = PLACEHOLDER_DIR/.matlab/generic_cluster_jobs/HPC/"$COMPUTERNAME"
        % RemoteJobStorageLocation (Unix) = PLACEHOLDER_DIR/.matlab/generic_cluster_jobs/HPC/"$HOST"

        % Example hpcDesktop.conf file that prompts the user and keeps the $USERNAME/$USER variable as part of the RJSL:

        % # Remote Job Storage Location
        % # Directory on the cluster's file system to be used as the remote job storage location.
        % RemoteJobStorageLocation (Windows) = /proj/PLACEHOLDER_DIR/"$USERNAME"/.matlab/generic_cluster_jobs/HPC/"$COMPUTERNAME"
        % RemoteJobStorageLocation (Unix) = /proj/PLACEHOLDER_DIR/"$USER"/.matlab/generic_cluster_jobs/HPC/"$HOST"

        % Step Two (if not using remoteConnection) - Modify user prompt in iGetCustomDir.

        if contains(cluster.AdditionalProperties.RemoteJobStorageLocation, 'PLACEHOLDER_DIR')
            customDir = iGetCustomDir(cluster, true);
            cluster.AdditionalProperties.RemoteJobStorageLocation = replace(cluster.AdditionalProperties.RemoteJobStorageLocation, 'PLACEHOLDER_DIR', customDir);
            if ~contains(cluster.AdditionalProperties.RemoteJobStorageLocation, customDir)
                error(['Failed to configure RemoteJobStorageLocation with custom value "%s".' ...
                    '\nManually verify that a correct RemoteJobStorageLocation value is configured.'], customDir)
            end
            % Save profile for future use.
            cluster.saveProfile
        end
    end
end

function customDir = iGetCustomDir(cluster, useRemoteConnection)

    if useRemoteConnection
        remoteConnection = getRemoteConnection(cluster);
        [FAILED, customDir] = remoteConnection.runCommand("echo $HOME");
        if FAILED
            error('Failed to configure cluster.  Unable to determine home directory on cluster.')
        end
        % Need to disconnect the connection.  Otherwise, MATLAB will report an error similar to
        % the following upon first job submission:
        %
        %  Warning: The current cluster is already using cluster host FQDN and remote job storage location
        %  PLACEHOLDER_DIR/$USER/.matlab/generic_cluster_jobs/cluster/$HOST
        %  The existing connection to FQDN will be replaced.
        %
        remoteConnection.disconnect
    else
        customDir = input('Input <descriptor> directory name (e.g. <customDir>): ','s');
        if isempty(customDir)
            error('Failed to configure cluster.')
        end
    end
end

%#ok<*DEFNU>
